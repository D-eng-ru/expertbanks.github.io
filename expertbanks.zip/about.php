<?php include 'Include/Header.php'; ?>
      
      <div class="container">
            <div class="row align-items-center block3">           
                <div class="col-md-6 blk3">
                <p style="margin: 0;"><i class="fi fi-br-eye"></i><small>О нашей команде</small></p>
                <h2 class="display-5">Команда экспертов <br>с большим кутасом</h2>
                <p>мы кАманда гарных хлипцеу та дивчин выходим на связь с дальнего рубежа, и счАстливи делать помогать Вы, наш милый клАент. мы працуемо з 2001 року и вообще идем на взлет вот уже 20 лет. в нашем портфолио более 100500 (овер 9000+) успешных кейсов. Будем рады поработать это для Вы</p>
                <ul class="list-group list-group-horizontal">
                    <li class="list-group-item"><h2 style="text-align: center">256</h2><p>Успешных кейсов</p></li>
                    <li class="list-group-item"><h2 style="text-align: center">10</h2><p>Лет опыта</p></li>
                    <li class="list-group-item"><h2 style="text-align: center">Более 200</h2><p>Довольных клиентов</p></li>
                </ul>
                </div>
                <div class="col-md-6 blk3_image">
                <img class="img-fluid rounded" src="images/About-Us-img.jpg" alt="Ипотека в Испании">
                </div>
            </div>
    </div>
      
 <?php include 'Include/Footer.php'; ?>
<!-- Footer -->
    
      
      
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
      
     <script src="https://kit.fontawesome.com/93c7301c02.js" crossorigin="anonymous"></script> 
    
    <script src="js/script.js"></script>
    
  </body>
    
    
</html>
