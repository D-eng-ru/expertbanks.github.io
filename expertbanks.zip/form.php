<?php include 'Include/Header.php'; ?>
<body>
      
      <div class="container-flex block-1-bg">
    <!-- BLOCK 1 
        <div class="container text-center">
            <div class="row align-items-center block1">           
                <div class="col blk1">
                <p style="margin: 0;"><i class="fi fi-br-eye"></i><small>Как получить ипотеку в Испании?</small></p>
                <h2 class="display-4">Ипотека в Испании<br> - это <u>просто</u>!</h2>
                <p>Подробная информация о том, как получить ипотеку на покупку жилья в Испании. Документы, ставки, сроки выплаты, примеры расчета ипотеки, рекомендации.</p>
                <button type="button" class="btn btn-dark">Подробнее</button>
                <button type="button" class="btn btn-outline-primary">Бесплатная консультация</button>
                </div>
            
                <div class="col blk1_1">
                <img src="images/banner_block1.png" class="img-fluid float-end" alt="Ипотека в Испании">
                </div>
            </div>
        </div>
    </div>  -->
      
     <!-- BLOCK 2 
      
      <div class="container-flex block-2-bg">
          <div class="container block-2 text-center">
              <h2 class="display-5">Ипотека — это просто!</h2>
              <p>Я иногда себя презираю... Не оттого ли я презираю других?</p>
              <button type="button" class="btn btn-outline-primary">Бесплатная консультация</button>
          </div>
      </div> -->
        
     <!-- BLOCK 3 
      
    <div class="container">
            <div class="row align-items-center block3">           
                <div class="col-md-6 blk3">
                <p style="margin: 0;"><i class="fi fi-br-eye"></i><small>О нашей команде</small></p>
                <h2 class="display-5">Команда экспертов с<br> большим опытом</h2>
                <p>мы кАманда гарных хлипцеу та дивчин выходим на связь с дальнего рубежа, и счАстливи делать помогать Вы, наш милый клАент. мы працуемо з 2001 року и вообще идем на взлет вот уже 20 лет. в нашем портфолио более 100500 (овер 9000+) успешных кейсов. Будем рады поработать это для Вы</p>
                <ul class="list-group list-group-horizontal">
                    <li class="list-group-item"><h2 style="text-align: center">256</h2><p>Успешных кейсов</p></li>
                    <li class="list-group-item"><h2 style="text-align: center">10</h2><p>Лет опыта</p></li>
                    <li class="list-group-item"><h2 style="text-align: center">Более 200</h2><p>Довольных клиентов</p></li>
                </ul>
                </div>
                <div class="col-md-6 blk3_image">
                <img class="img-fluid rounded" src="images/About-Us-img.jpg" alt="Ипотека в Испании">
                </div>
            </div>
    </div> -->
      
    <!-- BLOCK 4
      
    <div class="container block4">
        <div class="row justify-content-md-center block4-title">
        <div class="col-md-6">
        <h2 class="display-5">Наши услуги</h2>
        <p class="subtext">Подробная информация о том, как получить ипотеку на покупку жилья в Испании. Документы, ставки, сроки выплаты, примеры расчета ипотеки, рекомендации.</p>
        </div>
        </div>
        <div class="row align-items-center block4">
            <div class="col services-card">
                <img src="images/icons/icon-1.png" class="services-icon" alt="...">
                <h5 class="services-title">Card title</h5>
                <p class="services-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <button type="button" class="btn btn-outline-dark">Подробнее</button>
            </div>
            <div class="col services-card">
                <img src="images/icons/icon-2.png" class="services-icon" alt="...">
                <h5 class="services-title">Card title</h5>
                <p class="services-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <button type="button" class="btn btn-outline-dark">Подробнее</button>               
            </div>
            <div class="col services-card">
                <img src="images/icons/icon-3.png" class="services-icon" alt="...">
                <h5 class="services-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <button type="button" class="btn btn-outline-dark">Подробнее</button>
            </div>
            <div class="col services-card">
                <img src="images/icons/icon-3.png" class="services-icon" alt="...">
                <h5 class="services-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <button type="button" class="btn btn-outline-dark">Подробнее</button>
            </div>            
        </div>
    </div> -->
          
          
          
          
          
          
          
          
 <!-- <div class="container"> 
   <div class="row">
       <div class="col p-4">
           
           
   <form>
       
         
       
       <div class="input-group mb-3" style="width: 70%;">
              <span class="input-group-text">Name</span>
                <input type="text" class="form-control" aria-label="Name" aria-describedby="inputGroup-sizing-sm">

       </div>
       
       <div class="input-group mb-3" style="width: 70%;">
              <span class="input-group-text">Phone</span>
                <input type="tel" class="form-control" aria-label="Phone" aria-describedby="inputGroup-sizing-sm" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}">
           <small>Format: 123 - 45 - 678</small>

       </div>
       
       
       
       <div class="input-group mb-3" style="width: 70%;">
            <label class="input-group-text" for="inputGroupSelect01">Country</label>
            <select class="form-select" id="inputGroupSelect01">
                    <option selected>Choose...</option>
                    <option value="1">Spain</option>
                    <option value="2">Germany</option>
                    <option value="3">Nagonia</option>
            </select>
       </div>
       
       <div class="input-group mb-3" style="width: 70%;">
              <span class="input-group-text">Comments</span>
                <textarea class="form-control" aria-label="Comments"></textarea>

       </div> -->
       
       <div class="container-fluid">
   	<div class="row justify-content-center">
		<div class="col-12 col-md-8 col-lg-6 p-3">
            <h4>Contact Us</h4>


                    <!--Form with header-->

                    <div class="input-group mb-3">
              <span class="input-group-text">Name</span>
                <input type="text" class="form-control" aria-label="Name" aria-describedby="inputGroup-sizing-sm">

       </div>
       
            
            <div class="input-group mb-3">
              <span class="input-group-text">Phone</span>
                <input type="tel" class="form-control" aria-label="Phone" aria-describedby="inputGroup-sizing-sm" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" placeholder="999-99-999">
           

       </div>
                   
            
            <div class="input-group mb-3" style="width: 70%;">
            <label class="input-group-text" for="inputGroupSelect01">Country</label>
            <select class="form-select" id="inputGroupSelect01">
                    <option selected>Choose...</option>
                    <option value="1">Spain</option>
                    <option value="2">Germany</option>
                    <option value="3">Nagonia</option>
            </select>
       </div>
                 
            <div class="input-group mb-3">
              <span class="input-group-text">Comments</span>
                <textarea class="form-control" aria-label="Comments"></textarea>

       </div>
            
            
            
            
            <!--Form with header-->


                </div>
	</div>
</div>
       
        
       
  
           </div>
        
  
          
          
          
          
          
          
          
          
          
          
          
      
      
      <!-- Footer -->
     <?php include 'Include/Footer.php'; ?>
<!-- Footer -->
    
      
      
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
      
     <script src="https://kit.fontawesome.com/93c7301c02.js" crossorigin="anonymous"></script> 
    
    <script src="js/script.js"></script>
    
  </body>
    
    
</html>
