<?php include 'Include/Header.php'; ?>
<body>      
      
    <div style="background-color: #ccc" class="container-fluid">
	       <div class="row justify-content-center">
		      <div class="form-container col-12 col-md-8 col-lg-6 pb-5">
                  <h2 class="text-center">Связаться с нами</h2>
                  <form action="#">
                  <div class="form-group mb-3">
                    <lebel class="input-group-text" id="inputGroup-sizing-default">Ваше имя</lebel>
                    <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
                    </div>
                  <div class="form-group mb-3">
                    <lebel class="input-group-text" id="inputGroup-sizing-default">Ваш телефон</lebel>
                    <input type="tel" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" id="phone" name="phone" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" placeholder="xxx-xx-xxx"> 
                  </div>
                  <div class="form-group mb-3">
                    <lebel class="input-group-text" id="inputGroup-sizing-default">Ваш e-mail</lebel>
                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
                  </div>
                  <div class="form-group mb-3">
                    <label class="input-group-text" for="inputGroupSelect01">Страна</label>
                    <select class="form-select" id="inputGroupSelect01">
                        <option selected>Выберите...</option>
                        <option value="1">Испания</option>
                        <option value="2">Португалия</option>
                        <option value="3">Польша</option>
                        <option value="3">Канада</option>
                        <option value="3">Коста-Рика</option>
                    </select>
                  </div>
                  <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Ваше сообщение</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                  </div>
                  <div class="col-12">
                       <div class="col-12">
                        <button class="btn btn-primary" type="submit">Отправить заявку</button>
                        </div>
                  </div>
                </form>
          </div>
      </div>
    </div>
      
       
    
      
      
      
      
      
      
      
      
      
      
      
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
          
          



      <!-- Footer -->
<?php include 'Include/Footer.php'; ?>
<!-- Footer -->
    
      
      
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

      
     <script src="https://kit.fontawesome.com/93c7301c02.js" crossorigin="anonymous"></script> 
    
    <script src="js/script.js"></script>
    
  </body>
    
    
</html>
