    window.sr = ScrollReveal();
        sr.reveal('.navbar', {
            duration: 2000,
            distance: '20px',
            origin: 'bottom'
        }); 
        sr.reveal('.blk1', {
            duration: 2000,
            distance: '20px',
            origin: 'left'
        }); 
        sr.reveal('.blk1_1', {
            duration: 2000,
            distance: '30px',
            origin: 'right'
        }); 
        sr.reveal('.block-2', {
            duration: 2000,
            distance: '30px',
            origin: 'bottom'
        }); 
        sr.reveal('.blk3', {
            duration: 2000,
            distance: '30px',
            origin: 'left'
        }); 
          sr.reveal('.blk3_image', {
            duration: 2000,
            distance: '30px',
            origin: 'right'
        }); 
          sr.reveal('.block4-title', {
            duration: 2000,
            distance: '30px',
            origin: 'bottom'
        }); 
          sr.reveal('.services-card', {
            duration: 2000,
            distance: '30px',
            origin: 'bottom'
        }); 
          sr.reveal('footer', {
            duration: 2000,
            distance: '30px',
            origin: 'bottom'
        }); 
<<<<<<< Updated upstream
          sr.reveal('.carousel-inner', {
            duration: 2000,
            distance: '30px',
            origin: 'bottom'
        }); 
=======
>>>>>>> Stashed changes

